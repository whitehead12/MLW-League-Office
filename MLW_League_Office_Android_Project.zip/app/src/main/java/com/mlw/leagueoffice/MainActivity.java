package com.mlw.leagueoffice;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.AtomicFile;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

public class MainActivity extends Activity {
    private static final String APP_URL = "https://mlw.local/index.html";
    private static final int PICK_FILE = 100, SAVE_BACKUP = 101;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private byte[] pendingBackup;
    private AtomicFile database;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        database = new AtomicFile(new File(getFilesDir(), "mlw-universe.json"));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(11,14,19));
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new NativeBridge(), "MLWAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !APP_URL.equals(r.getUrl().toString());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (APP_URL.equals(r.getUrl().toString())) {
                    try {
                        return new WebResourceResponse("text/html", "UTF-8", 200, "OK", Collections.singletonMap("Cache-Control", "no-store"), getAssets().open("index.html"));
                    } catch (Exception ignored) { }
                }
                return new WebResourceResponse("text/plain", "UTF-8", 404, "Not found", Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    startActivityForResult(params.createIntent(), PICK_FILE);
                } catch (Exception e) {
                    fileCallback.onReceiveValue(null);
                    fileCallback = null;
                    toast("No compatible file picker available.");
                }
                return true;
            }
        });
        web.loadUrl(APP_URL);
    }

    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_LONG).show(); }
    private final class NativeBridge {
        @JavascriptInterface public synchronized String loadDatabase() {
            try { return new String(database.readFully(), StandardCharsets.UTF_8); }
            catch (FileNotFoundException e) { return null; }
            catch (Exception e) { throw new IllegalStateException("Unable to read saved MLW database", e); }
        }
        @JavascriptInterface public synchronized boolean saveDatabase(String json) {
            FileOutputStream out = null;
            try {
                out = database.startWrite();
                out.write(json.getBytes(StandardCharsets.UTF_8));
                database.finishWrite(out);
                return true;
            } catch (Exception e) {
                if (out != null) database.failWrite(out);
                return false;
            }
        }
        @JavascriptInterface public void exportBackup(String json, String fileName) {
            runOnUiThread(() -> {
                if (pendingBackup != null) { toast("Finish the current backup first."); return; }
                pendingBackup = json.getBytes(StandardCharsets.UTF_8);
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, fileName);
                try { startActivityForResult(intent, SAVE_BACKUP); }
                catch (Exception e) { pendingBackup = null; toast("Unable to open backup file picker."); }
            });
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_FILE && fileCallback != null) {
            ValueCallback<Uri[]> cb = fileCallback;
            fileCallback = null;
            cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
        } else if (request == SAVE_BACKUP) {
            byte[] bytes = pendingBackup;
            pendingBackup = null;
            if (result == RESULT_OK && data != null && data.getData() != null && bytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (out == null) throw new IllegalStateException("No output stream");
                    out.write(bytes);
                    toast("MLW backup saved.");
                } catch (Exception e) { toast("Backup failed. Please try again."); }
            }
        }
    }
    @Override protected void onDestroy() {
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        if (web != null) { web.removeJavascriptInterface("MLWAndroid"); web.destroy(); }
        super.onDestroy();
    }
}
