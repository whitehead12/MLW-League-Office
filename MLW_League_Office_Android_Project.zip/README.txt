MLW LEAGUE OFFICE 4.1 — ANDROID PROJECT (SOURCE, NOT APK)

This package embeds the last MLW League Office dashboard (4.1), including the
opening-night seed, roster release/archive/reinstate, bio creator, show booking,
records, rankings, storyboards, and history. No Replit, web server or internet
permission is required to run the installed app. Existing browser edits are NOT
included; export your current JSON backup before switching and import it inside
MLW once installed. The Android wrapper uses app-private atomic file storage,
Android's file chooser for image/backup imports and the native document picker
for exporting JSON backups. Offline creative helpers remain rule-based.

BUILD ON A COMPUTER (Android Studio)
1. Install Android Studio (JDK 17, Android SDK Platform 35 and Build Tools 35).
2. Extract this ZIP. Open its top-level project directory in Android Studio.
3. When asked for Gradle, use Gradle 8.9 (the project uses AGP 8.7.3). This
   archive does not contain a Gradle wrapper distribution. If necessary install
   Gradle 8.9 and select its installation in Android Studio's Gradle settings.
4. Sync the project. Choose Build > Generate App Bundles or APKs > Generate APKs
   (or run `gradle :app:assembleDebug` from the project directory).
5. Find app/build/outputs/apk/debug/app-debug.apk. This is a debug-signed APK.
   Keep the same signing key for future updates to retain app data. Android
   Studio normally uses the same debug keystore on the same computer.
6. Transfer the APK to your Pixel and open it using Files. If Android asks,
   allow installation from that specific source. Disable that permission after.
7. Open MLW League Office from the app drawer and drag its icon onto the home
   screen. Import your previous backup if you have one.

OPTIONAL CLOUD BUILD (not needed to run the app)
The source contains a manual GitHub Actions build workflow. Put the project in
an empty private repository, enable Actions, run 'Build MLW Android APK', and
retrieve the resulting APK artifact. Each fresh CI runner may use a different
debug signing key; export a backup before uninstalling/reinstalling. A stable
signing key is recommended for ongoing upgrades.

STATUS
JavaScript syntax was checked. The native Android wrapper and Gradle build have
NOT been compiled or tested on Android because the current environment does not
have the Android SDK or access to its download servers. This is a source project,
not an installable application yet. No current match results were invented or
preloaded beyond the original opening-night seed.
